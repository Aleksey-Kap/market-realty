from django.apps import AppConfig


class FlatConfig(AppConfig):
    name = 'flat'
